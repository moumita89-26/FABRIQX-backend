from django.apps import AppConfig


class InfluencersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'influencers'
    verbose_name = 'Influencers & Affiliates'
